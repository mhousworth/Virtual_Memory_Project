//
//	virt_mem.c
//	virt_mem
//
//	Functions:
//		getpage
//		getoffset
//		getpage_offset
//
//  Created by William McCarthy on 3/23/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//
//
//	Modified by Michael Housworth on 4/27/19
//
//	Allows modified pages in memory to be written back to page file, by demand(replacement policy), and at the end of the program
//	Page file is Binary.bin, contains 10 entries of 0 - 9 as characters, total of 100 entries
//	Value is modified in memory, added 17 to change into alphabetical characters A - J
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#pragma warning(disable : 4996)

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 1
#define FRAME_SIZE  1

// SET TO 128 to use replacement policy: FIFO or LRU, boolean "replace_policy" specifies which is used in main function
#define FRAME_NUM 40

#define PT_SIZE 100
#define TLB_SIZE 16

typedef enum boolean boolean;
enum boolean { false = 0, true = 1 };

// Struct for a Page Table entry
typedef struct PT_entry PT_entry;
struct PT_entry {
	boolean present;
	boolean used;
	boolean modified;
	unsigned int page_num;
	unsigned int frame_num;
};

//-------------------------------------------------------------------
unsigned int getpage(size_t x) { return (0xff00 & x) >> 8; }
unsigned int getoffset(unsigned int x) { return (0xff & x); }

void getpage_offset(unsigned int x) {
	unsigned int page = getpage(x);
	unsigned int offset = getoffset(x);
	printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
		(page << 8) | getoffset(x), page * 256 + offset);
}


// Updates a page in the Page Table with associated frame number
void update_frame_PT(PT_entry (*PT)[PT_SIZE], unsigned int page_num, unsigned int frame_num) {
	(*PT)[page_num].frame_num = frame_num;
	(*PT)[page_num].present = true;
	(*PT)[page_num].used = true;
}

// For FIFO replacement policy
// Returns the page number of a Page Table entry with a matching frame
int find_frame_PT(PT_entry (*PT)[PT_SIZE], unsigned int frame) {

	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT till a PRESENT page is found with a matching frame
		if ((*PT)[i].frame_num == frame && (*PT)[i].present == true) {
			return i;
		}
	}

	//Could not find a matching frame
	return -1;
}

// For LRU replacement policy
// Returns the page number of a Page Table entry that has not been used recently
unsigned int get_used_PT(PT_entry (*PT)[PT_SIZE]) {

	unsigned int unused = -1;
	
	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT to find a PRESENT page that is unused
		if ((*PT)[i].used == false && (*PT)[i].present == true) {
			return (unsigned int)i;
		}
	}

	// All present pages have been used recently, set all page entry used flags to false
	for (int i = 0; i < PT_SIZE; i++) {
		(*PT)[i].used = false;
	}

	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT to find a PRESENT page that is unused
		if ((*PT)[i].used == false && (*PT)[i].present == true) {
			// Return the first one found
			return (unsigned int)i;
		}
	}

	return (unsigned int)-1;
}

// Returns the index of a TLB entry with a matching page
int check_TLB(PT_entry (*TLB)[TLB_SIZE], unsigned int page) {

	for (int i = 0; i < TLB_SIZE; i++) {
		// Iterate through TLB to find a matching page and is present in memory
		if ((*TLB)[i].page_num == page) {
				return i;
		}
	}

	// If a match is not found
	return -1;
}

// Adds a Page Table entry to the TLB
void TLB_add(PT_entry (*TLB)[TLB_SIZE], int index, PT_entry entry) {
	(*TLB)[index] = entry;
}

// "Removes" a Page Table entry from the TLB
void TLB_remove(PT_entry(*TLB)[TLB_SIZE], int index) {
	// Set to -1 to identify non existing page number
	(*TLB)[index].page_num = (unsigned int)-1;
	(*TLB)[index].present = false;
}

// Loads the frame into a buffer which is then written to the file containing page data
void write_modified(FILE* bin, unsigned int page, unsigned int frame, char* frame_ptr) {

	char buf[BUFLEN];

	// Read from Physical Memory
	for (int i = 0; i < FRAME_SIZE; i++) {
		// Write by each character
		buf[i] = *(frame_ptr + (frame * FRAME_SIZE) + i);
	}

	// Seek to page in file
	fseek(bin, page * FRAME_SIZE, SEEK_SET);
	// Read in page to buffer
	fwrite(buf, FRAME_SIZE, 1, bin);

	printf("Writting from Frame: %u to Page: %u in Page File\n", frame, page);
}

int main(int argc, const char * argv[]) {

	//Open file BACKING_STORE.bin, specify "rb" to read binary
	FILE* fback = fopen("Binary.bin", "rb+");
	if (fback == NULL) { fprintf(stderr, "Could not open file: 'Binary.bin'\n");  exit(FILE_ERROR); }

	char buf[BUFLEN];
	unsigned int page, offset = 0, physical_add, frame = 0, val = 0;
	unsigned int logic_add;                  // read from file address.txt
	unsigned int virt_add, phys_add, value;  // read from file correct.txt

	// Tracks how many frames in memory are used, for replacement policies
	int frames_used = 0;
	// Flag to show if main memory has been filled, for replacement policies
	boolean mem_full = false;

	// Track page faults and TLB Hits
	int p_fault = 0, tlb_hit = 0;

	// Set to 0 uses FIFO, Set to 1 uses LRU
	boolean replace_policy = 0;

	// Create frame pointer for physical memory
	char* frame_ptr;

	// Create/Allocate Physical Memory for appropriate number of frame entries
	frame_ptr = (char*)malloc(FRAME_NUM * FRAME_SIZE);

	// Page Table
	PT_entry PT[PT_SIZE];
	
	// Initialize Page Table Entries
	for (int i = 0; i < PT_SIZE; i++) {
		PT[i].page_num = (unsigned int)i;
		PT[i].present = false;
		PT[i].used = false;
		PT[i].modified = false;
	}

	// TLB contains Page Table Entries
	PT_entry TLB[TLB_SIZE];

	// Initialize TLB Entries
	for (int i = 0; i < TLB_SIZE; i++) {
		TLB[i].page_num = (unsigned int)-1;
		TLB[i].present = false;
		TLB[i].used = false;
		TLB[i].modified = false;
	}

	// Track location of last added TLB entry, used in TLB adds, will be set to 0 when incremented passed 16
	int tlb_track = 0;
	

	// For each of the 100 entries in Binary.bin
	// Loads Pages into Frames in Memory
	for (int o = 0; o < 100; o++) {

		page = (unsigned int)o;

		//Check if there is a matching page entry in the TLB
		int result = check_TLB(&TLB, page);
		if (result >= 0) {	//TLB check
			tlb_hit++;

			// Set frame for physical address
			frame = TLB[result].frame_num;

			// Set used flag
			PT[page].used = true;
		}
		// Check Page Table
		else if (PT[page].present) {
			// Set frame for physical address
			frame = PT[page].frame_num;

			// Set used flag
			PT[page].used = true;

			// Add to TLB
			TLB_add(&TLB, tlb_track++, PT[page]);

			if (tlb_track > 15)
				tlb_track = 0;
		}
		// Page Fault, find page in BACKING_STORE
		else {
			p_fault++;

			if (frames_used >= FRAME_NUM) {
				// FIFO
				// Reset frames_used, thus replace frames in order of which pages were loaded in
				if(replace_policy == 0)
					frames_used = 0;
				// Set flag to show main memory has been filled
				mem_full = true;
			}

			frame = frames_used;

			// Check if main memory is filled
			if (mem_full) {
				
				if (replace_policy == 0) {
					// FIFO
					// Search for the page using current frame
					int p = find_frame_PT(&PT, frame);
					if (p != -1) {
						// Set present flag to false
						PT[p].present = false;

						//Check is modified, write if so
						if (PT[p].modified == true)
							write_modified(fback, p, frame, frame_ptr);
					}

					// Check if page is in TLB, if so remove it
					int t = check_TLB(&TLB, (unsigned int)p);
					if (t != -1)
						TLB_remove(&TLB, t);

				}
				else {
					// LRU(Nonfunctional, either memory READ or WRITE issues)
					// Get a page that hasn't been used recently
					unsigned int p = get_used_PT(&PT);

					// Get frame from unused page entry and set frame for physical address
					frame = PT[p].frame_num;

					// Set present flag to false
					PT[p].present = false;

					//Check is modified, write if so
					if (PT[p].modified == true)
						write_modified(fback, p, frame, frame_ptr);

					// Check if page is in TLB, if so remove it
					int t = check_TLB(&TLB, (unsigned int)p);
					if (t != -1)
						TLB_remove(&TLB, t);
				}
			}
			

			// Load page into main memory

			// Seek to page in file
			fseek(fback, page * FRAME_SIZE, SEEK_SET);
			// Read in page to buffer
			fread(buf, FRAME_SIZE, 1, fback);

			// Write to Physical Memory
			for (int i = 0; i < FRAME_SIZE; i++) {
				// Write by each character
				*(frame_ptr + (frame * FRAME_SIZE) + i) = buf[i];
			}

			// Update Page Table
			update_frame_PT(&PT, page, frame);

			// Add to TLB
			TLB_add(&TLB, tlb_track++, PT[page]);

			if (tlb_track > 15)
				tlb_track = 0;

			frames_used++;
		}

		// Build Physical Address
		physical_add = (frame * FRAME_SIZE) + offset;

		val = *(frame_ptr + physical_add);

		printf("Read Page: %u -- From Frame: %u -- Value is: %u\n", page, frame, val);

		// MODIFY Page in memory
		val = val + 17;
		*(frame_ptr + physical_add) = val;

		printf("-- Modifying Value to %u\n", val);

		// Update Page Table
		PT[page].modified = true;
		
		//Check and Update TLB
		result = check_TLB(&TLB, page);
		if (result >= 0) {	//TLB check

			// Set used flag
			TLB[result].modified = true;
		}
	}

	// Before exiting program
	// For each Page Table Entry
	for (int i = 0; i < PT_SIZE; i++) {
		// Check if the page was modified, write to page file if so
		if (PT[i].modified == true)
			write_modified(fback, i, PT[i].frame_num, frame_ptr);
	}


	fclose(fback);
	
	// Deallocate memory
	free(frame_ptr);
	frame_ptr = NULL;

	return 0;
}
