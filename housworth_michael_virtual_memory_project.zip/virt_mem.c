//
//	virt_mem.c
//	virt_mem
//
//	Functions:
//		getpage
//		getoffset
//		getpage_offset
//
//  Created by William McCarthy on 3/23/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//
//
//	Modified by Michael Housworth on 4/12/19
//
//	On line 33 set FRAME_NUM to 256 to not used replacement policy, or 128 to use replacement policy
//	On line 168 set replace_policy to 0 for FIFO or 1 for LRU
//	On line 322 can uncomment assert if using FRAME_NUM of 256

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#pragma warning(disable : 4996)

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256

// SET TO 128 to use replacement policy: FIFO or LRU, boolean "replace_policy" specifies which is used in main function
#define FRAME_NUM 128

#define PT_SIZE 256
#define TLB_SIZE 16

typedef enum boolean boolean;
enum boolean { false = 0, true = 1 };

// Struct for a Page Table entry
typedef struct PT_entry PT_entry;
struct PT_entry {
	boolean present;
	boolean used;
	unsigned int page_num;
	unsigned int frame_num;
};

//-------------------------------------------------------------------
unsigned int getpage(size_t x) { return (0xff00 & x) >> 8; }
unsigned int getoffset(unsigned int x) { return (0xff & x); }

void getpage_offset(unsigned int x) {
	unsigned int page = getpage(x);
	unsigned int offset = getoffset(x);
	printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
		(page << 8) | getoffset(x), page * 256 + offset);
}


// Updates a page in the Page Table with associated frame number
void update_frame_PT(PT_entry (*PT)[PT_SIZE], unsigned int page_num, unsigned int frame_num) {
	(*PT)[page_num].frame_num = frame_num;
	(*PT)[page_num].present = true;
	(*PT)[page_num].used = true;
}

// For FIFO replacement policy
// Returns the page number of a Page Table entry with a matching frame
int find_frame_PT(PT_entry (*PT)[PT_SIZE], unsigned int frame) {

	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT till a PRESENT page is found with a matching frame
		if ((*PT)[i].frame_num == frame && (*PT)[i].present == true) {
			return i;
		}
	}

	//Could not find a matching frame
	return -1;
}

// For LRU replacement policy
// Returns the page number of a Page Table entry that has not been used recently
unsigned int get_used_PT(PT_entry (*PT)[PT_SIZE]) {

	unsigned int unused = -1;
	
	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT to find a PRESENT page that is unused
		if ((*PT)[i].used == false && (*PT)[i].present == true) {
			return (unsigned int)i;
		}
	}

	// All present pages have been used recently, set all page entry used flags to false
	for (int i = 0; i < PT_SIZE; i++) {
		(*PT)[i].used = false;
	}

	for (int i = 0; i < PT_SIZE; i++) {
		// Iterate through PT to find a PRESENT page that is unused
		if ((*PT)[i].used == false && (*PT)[i].present == true) {
			// Return the first one found
			return (unsigned int)i;
		}
	}

	return (unsigned int)-1;
}

// Returns the index of a TLB entry with a matching page
int check_TLB(PT_entry (*TLB)[TLB_SIZE], unsigned int page) {

	for (int i = 0; i < TLB_SIZE; i++) {
		// Iterate through TLB to find a matching page and is present in memory
		if ((*TLB)[i].page_num == page) {
				return i;
		}
	}

	// If a match is not found
	return -1;
}

// Adds a Page Table entry to the TLB
void TLB_add(PT_entry (*TLB)[TLB_SIZE], int index, PT_entry entry) {
	(*TLB)[index] = entry;
}

// "Removes" a Page Table entry from the TLB
void TLB_remove(PT_entry(*TLB)[TLB_SIZE], int index) {
	// Set to -1 to identify non existing page number
	(*TLB)[index].page_num = (unsigned int)-1;
	(*TLB)[index].present = false;
}



int main(int argc, const char * argv[]) {
	//Open file address.txt
	FILE* fadd = fopen("addresses.txt", "r");
	if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR); }

	//Open file correct.txt
	FILE* fcorr = fopen("correct.txt", "r");
	if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR); }

	//Open file BACKING_STORE.bin, specify "rb" to read binary
	FILE* fback = fopen("BACKING_STORE.bin", "rb");
	if (fback == NULL) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n");  exit(FILE_ERROR); }

	char buf[BUFLEN];
	unsigned int page, offset, physical_add, frame = 0, val = 0;
	unsigned int logic_add;                  // read from file address.txt
	unsigned int virt_add, phys_add, value;  // read from file correct.txt

	// Tracks how many frames in memory are used, for replacement policies
	int frames_used = 0;
	// Flag to show if main memory has been filled, for replacement policies
	boolean mem_full = false;

	// Track page faults and TLB Hits
	int p_fault = 0, tlb_hit = 0;

	// Set to 0 uses FIFO, Set to 1 uses LRU
	boolean replace_policy = 0;

	// Create frame pointer for physical memory
	char* frame_ptr;

	// Create/Allocate Physical Memory for appropriate number of frame entries
	frame_ptr = (char*)malloc(FRAME_NUM * FRAME_SIZE);

	// Page Table
	PT_entry PT[PT_SIZE];
	
	// Initialize Page Table Entries
	for (int i = 0; i < PT_SIZE; i++) {
		PT[i].page_num = (unsigned int)i;
		PT[i].present = false;
		PT[i].used = false;
	}

	// TLB contains Page Table Entries
	PT_entry TLB[TLB_SIZE];

	// Initialize TLB Entries
	for (int i = 0; i < TLB_SIZE; i++) {
		TLB[i].page_num = (unsigned int)-1;
		TLB[i].present = false;
		PT[i].used = false;
	}

	// Track location of last added TLB entry, used in TLB adds, will be set to 0 when incremented passed 16
	int tlb_track = 0;
	

	// For each of the 1000 entries in addresses.txt
	// Loads Pages into Frames in Memory
	// Reads the value in memory, by translating virtual addresses to physical addresses
	for (int o = 0; o < 1000; o++) {

		fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
			buf, buf, &phys_add, buf, &value);  // read from file correct.txt

		fscanf(fadd, "%d", &logic_add);  // read from file address.txt
		page = getpage(logic_add);
		offset = getoffset(logic_add);

		//Check if there is a matching page entry in the TLB
		int result = check_TLB(&TLB, page);
		if (result >= 0) {	//TLB check
			tlb_hit++;

			// Set frame for physical address
			frame = TLB[result].frame_num;

			// Get page
			page = TLB[result].page_num;

			// Set used flag
			PT[page].used = true;
		}
		// Check Page Table
		else if (PT[page].present) {
			// Set frame for physical address
			frame = PT[page].frame_num;

			// Set used flag
			PT[page].used = true;

			// Add to TLB
			TLB_add(&TLB, tlb_track++, PT[page]);

			if (tlb_track > 15)
				tlb_track = 0;
		}
		// Page Fault, find page in BACKING_STORE
		else {
			p_fault++;

			if (frames_used >= FRAME_NUM) {
				// FIFO
				// Reset frames_used, thus replace frames in order of which pages were loaded in
				if(replace_policy == 0)
					frames_used = 0;
				// Set flag to show main memory has been filled
				mem_full = true;
			}

			frame = frames_used;

			// Check if main memory is filled
			if (mem_full) {
				
				if (replace_policy == 0) {
					// FIFO
					// Search for the page using current frame
					int p = find_frame_PT(&PT, frame);
					if (p != -1) {
						// Set present flag to false
						PT[p].present = false;
					}

					// Check if page is in TLB, if so remove it
					int t = check_TLB(&TLB, (unsigned int)p);
					if (t != -1)
						TLB_remove(&TLB, t);
				}
				else {
					// LRU(Nonfunctional, either memory READ or WRITE issues)
					// Get a page that hasn't been used recently
					unsigned int p = get_used_PT(&PT);

					// Get frame from unused page entry and set frame for physical address
					frame = PT[p].frame_num;

					// Set present flag to false
					PT[p].present = false;

					// Check if page is in TLB, if so remove it
					int t = check_TLB(&TLB, (unsigned int)p);
					if (t != -1)
						TLB_remove(&TLB, t);
				}
			}
			

			// Load page into main memory

			// Seek to page in file
			fseek(fback, page * FRAME_SIZE, SEEK_SET);
			// Read in page to buffer
			fread(buf, FRAME_SIZE, 1, fback);

			// Write to Physical Memory
			for (int i = 0; i < FRAME_SIZE; i++) {
				// Write by each character
				*(frame_ptr + (frame * FRAME_SIZE) + i) = buf[i];
			}


			// Update Page Table
			update_frame_PT(&PT, page, frame);

			// Add to TLB
			TLB_add(&TLB, tlb_track++, PT[page]);

			if (tlb_track > 15)
				tlb_track = 0;

			frames_used++;
		}

		// Build Physical Address
		physical_add = (frame * FRAME_SIZE) + offset;

		val = *(frame_ptr + physical_add);

		//assert(physical_add == phys_add); //Comment when using reduced main memory
		assert(val == value);
		// todo: read BINARY_STORE and confirm value matches read value from correct.txt
		printf("logical: %5u (page:%3u, offset:%3u) ---> physical: %5u (frame: %3u)---> value: %4d -- passed\n", logic_add, page, offset, physical_add, frame, (signed int)val);
		if (o % 5 == 0) { printf("\n"); }
	}

	printf("\nPage Fault Percentage: %1.3f%%", (double)p_fault / 1000);
	printf("\nTLB Hit Percentage: %1.3f%%\n\n", (double)tlb_hit / 1000);
	printf("ALL logical ---> physical assertions PASSED!\n");
	printf("\n\t\t...done.\n");

	fclose(fback);
	fclose(fcorr);
	fclose(fadd);
	
	// Deallocate memory
	free(frame_ptr);
	frame_ptr = NULL;

	return 0;
}
